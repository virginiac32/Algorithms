class BSTNode
  def initialize(value)
    @value = value
    @left
    @right
  end

  attr_accessor :left, :right
  attr_reader :value
end
